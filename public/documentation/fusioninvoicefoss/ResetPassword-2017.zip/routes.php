<?php

Route::group(['namespace' => 'FI\Modules\ResetPassword\Controllers'], function ()
{
    Route::get('resetpassword', ['uses' => 'ResetPasswordController@index', 'as' => 'resetPassword.index']);
    Route::post('resetpassword', ['uses' => 'ResetPasswordController@update', 'as' => 'resetPassword.update']);

    Route::get('resetpassword/success', ['uses' => 'ResetPasswordController@success', 'as' => 'resetPassword.success']);
});