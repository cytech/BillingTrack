<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>{{ trans('fi.welcome') }}</title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>

    <link href="{{ asset('favicon.png') }}" rel="icon" type="image/png">
    <link href="{{ asset('assets/bootstrap/css/bootstrap.min.css') }}" rel="stylesheet" type="text/css"/>
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
    <link href="{{ asset('assets/dist/css/AdminLTE.min.css') }}" rel="stylesheet" type="text/css"/>
</head>
<body class="login-page">
<div class="login-box">
    <div class="login-box-body">
        <p class="login-box-msg">FusionInvoice Password Reset Utility</p>
        @include('layouts._alerts')

        <p>Your password has successfully been reset.</p>

        <p><strong>Delete the /app/Modules/ResetPassword folder from your
                server - otherwise anybody who finds this will be able to reset your password.</strong></p>

        <p><a href="{{ route('session.login') }}">Log In</a></p>

    </div>
</div>

<script src="{{ asset('assets/plugins/jQuery/jQuery.min.js') }}"></script>
<script src="{{ asset('assets/bootstrap/js/bootstrap.min.js') }}" type="text/javascript"></script>

</body>
</html>